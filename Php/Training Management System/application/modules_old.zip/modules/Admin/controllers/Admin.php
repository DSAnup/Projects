<?php

defined('BASEPATH') OR exit('No direct script access allowed');

/**
* 
Developed By: Morshed Habib Sohel
Mobile: 01735254295
E-Mail: mhsohel017@gmail.com
*/
class Admin extends MX_Controller 
{
	
	function __construct()
	{
		parent::__construct();
		$this->load->model('Admin_model');
		$this->session->unset_userdata('update');
	}

	public function index(){
		$session=$this->session->userdata('userID');
		if(isset($session)){
			redirect(base_url() . 'Admin/index1');
		}
		$this->load->view('login');
	}
	public function login(){
		$email=$this->input->post('username');
		$password=md5($this->input->post('password'));
		$where=array('email'=>$email,'password'=>$password);
		$data=$this->Admin_model->SelectData_1('admin','*',$where);
		if ($data !== NULL) {
            $session['userID'] = $data->id;
            $session['name'] = $data->name;
            $this->session->set_userdata($session);
            redirect(base_url() . 'Admin/index1');
        } else {
            redirect(base_url() . 'Admin');
        }
	}
	public function logout(){
		$this->session->unset_userdata('name');
		$this->session->unset_userdata('userID');
		redirect(base_url() . 'Admin');
	}
	public function index1(){
		$session=$this->session->userdata('userID');
		if(!isset($session)){
			redirect(base_url() . 'Admin');
		}
		$this->load->view('index');
	}
	public function slider_manager($menu){
		$session=$this->session->userdata('userID');
		if(!isset($session)){
			redirect(base_url() . 'Admin');
		}
		$session = array('menu' =>$menu);
		$this->session->set_userdata($session);
		$data['query']=$this->Admin_model->SelectData('slider','*','');
		$this->session->unset_userdata('update');
		$this->load->view('sliders',$data);
	}

	public function add_slider(){
		$data['main_caption']=$this->input->post('main_caption');
		$data['sub_caption']=$this->input->post('sub_caption');
		$data['description']=$this->input->post('description');
		$data['position']=$this->input->post('position');

		$config['upload_path'] = './sliders/';
		$config['allowed_types'] = 'gif|jpg|png';
		$config['encrypt_name'] = TRUE;
		$config['max_size'] = 100000;
		$config['max_width'] = 102400;
		$config['max_height'] = 76800;
		$this->load->library('upload', $config);

		if (!$this->upload->do_upload('userfile')) {
			$error = array('error' => $this->upload->display_errors());
		} else {
			$data2 = array('upload_data' => $this->upload->data());
			$d = $data2['upload_data']['file_name'];
			$data['photo'] = $d;
		}
		$this->Admin_model->SaveData('slider',$data);
		redirect(base_url().'Admin/slider_manager/slider');
	}
	public function delete_slider($id){
		$where = array('id' =>$id);
		$previous=$this->Admin_model->SelectData_1('slider','*',$where);
		$path='sliders/'.$previous->photo;
		unlink($path);
		$this->Admin_model->DeleteData('slider',$where);
		$this->session->unset_userdata('update');
		redirect(base_url().'Admin/slider_manager/slider');
	}
	public function edit_slider($id){
		$session = array('update' =>'yes');
		$this->session->set_userdata($session);
		$where = array('id' =>$id);
		$data['q']=$this->Admin_model->SelectData_1('slider','*',$where);
		$data['query']=$this->Admin_model->SelectData('slider','*','');
		$this->load->view('update_slider',$data);
	}
	public function update_slider(){
		$id=$this->input->post('id');
		$where = array('id' =>$id);
		$data['main_caption']=$this->input->post('main_caption');
		$data['sub_caption']=$this->input->post('sub_caption');
		$data['description']=$this->input->post('description');
		$data['position']=$this->input->post('position');

		$config['upload_path'] = './sliders/';
		$config['allowed_types'] = 'gif|jpg|png';
		$config['encrypt_name'] = TRUE;
		$config['max_size'] = 100000;
		$config['max_width'] = 102400;
		$config['max_height'] = 76800;
		$this->load->library('upload', $config);

		if (!$this->upload->do_upload('userfile')) {
            //$error = array('error' => $this->upload->display_errors());
		} else {
			$data2 = array('upload_data' => $this->upload->data());
			$d = $data2['upload_data']['file_name'];
			$data['photo'] = $d;
			$previous=$this->Admin_model->SelectData_1('slider','*',$where);
			$path='sliders/'.$previous->photo;
			unlink($path);
		}
		$this->session->unset_userdata('update');
		$this->Admin_model->UpdateData('slider',$data,$where);
		redirect(base_url().'Admin/slider_manager/slider');
	}

	public function workshop($menu){
		$session=$this->session->userdata('userID');
		if(!isset($session)){
			redirect(base_url() . 'Admin');
		}
		$session = array('menu' =>$menu);
		$this->session->set_userdata($session);
		$data['query']=$this->Admin_model->get_workshop();
		$this->session->unset_userdata('update');
		$data['trainer']=$this->Admin_model->SelectData('trainer','*','');
		$this->load->view('workshop',$data);
	}
	public function add_workshop(){
		$data['name']=$this->input->post('name');
		$data['details']=$this->input->post('details');
		$data['trainer']=$this->input->post('trainer');
		$data['duration']=$this->input->post('duration');
		$data['date']=$this->input->post('date');
		$data['price']=$this->input->post('price');
		$this->Admin_model->SaveData('workshop',$data);
		redirect(base_url().'Admin/workshop/w');
	}

	public function edit_workshop($id){
		$session = array('update' =>'yes');
		$this->session->set_userdata($session);
		$where = array('id' =>$id);
		$data['q']=$this->Admin_model->SelectData('workshop','*',$where);
		$data['query']=$this->Admin_model->get_workshop();
		$data['trainer']=$this->Admin_model->SelectData('trainer','*','');
		$this->load->view('workshop',$data);
	}
	public function update_workshop(){
		$id=$this->input->post('id');
		$data['name']=$this->input->post('name');
		$data['details']=$this->input->post('details');
		$data['trainer']=$this->input->post('trainer');
		$data['duration']=$this->input->post('duration');
		$data['date']=$this->input->post('date');
		$data['price']=$this->input->post('price');

		$this->session->unset_userdata('update');
		$where = array('id' =>$id);
		$this->Admin_model->UpdateData('workshop',$data,$where);
		redirect(base_url().'Admin/workshop/w');
	}
	public function delete_workshop($id){
		$where = array('id' =>$id);
		$this->Admin_model->DeleteData('workshop',$where);
		redirect(base_url().'Admin/workshop/w');
	}
	public function trainers($menu){
		$session=$this->session->userdata('userID');
		if(!isset($session)){
			redirect(base_url() . 'Admin');
		}
		$session = array('menu' =>$menu);
		$this->session->set_userdata($session);
		$data['query']=$this->Admin_model->SelectData('trainer','*','');
		$this->load->view('trainers',$data);
	}
	public function add_trainer(){
		$data['name']=$this->input->post('name');
		$data['designation']=$this->input->post('designation');
		$data['experience']=$this->input->post('experience');
		$data['contact']=$this->input->post('contact');
		$data['address']=$this->input->post('address');
		$data['type']=$this->input->post('type');
		$data['skills']=$this->input->post('skills');
		$data['description']=$this->input->post('description');

		$count=$this->input->post('count');
		$icon=$this->input->post('icon');
		$link=$this->input->post('link');


		$config['upload_path'] = './trainers/';
		$config['allowed_types'] = 'gif|jpg|png';
		$config['encrypt_name'] = TRUE;
		$config['max_size'] = 100000;
		$config['max_width'] = 102400;
		$config['max_height'] = 76800;
		$this->load->library('upload', $config);

		if (!$this->upload->do_upload('userfile')) {
			$error = array('error' => $this->upload->display_errors());
		} else {
			$data2 = array('upload_data' => $this->upload->data());
			$d = $data2['upload_data']['file_name'];
			$data['photo'] = $d;
		}
		$this->Admin_model->SaveData('trainer',$data);
		$id=$this->Admin_model->get_max_id();
		$dd=array();
		for($i=0;$i<=$count;$i++){
			$dd['icon']=$icon[$i];
			$dd['link']=$link[$i];
			$dd['trainerID']=$id->id;
			$this->Admin_model->SaveData('social_link',$dd);
		}
		redirect(base_url().'Admin/trainers/trainer');
	}

	public function delete_trainer($id){
		$where = array('id' =>$id);
		$wheres = array('trainerID' =>$id);
		$this->Admin_model->DeleteData('trainer',$where);
		$this->Admin_model->DeleteData('social_link',$wheres);
		redirect(base_url().'Admin/trainers/trainer');
	}
	public function edit_trainer($id){
		// $this->session->unset_userdata('update');
		$session = array('update' =>'yes');
		$this->session->set_userdata($session);
		$where = array('id' =>$id);
		$wheres = array('trainerID' =>$id);
		$data['id']=$id;
		$data['q']=$this->Admin_model->SelectData_1('trainer','*',$where);
		$data['links']=$this->Admin_model->SelectData('social_link','*',$wheres);
		$data['query']=$this->Admin_model->SelectData('trainer','*','');
		$this->load->view('update_trainer',$data);
		// echo "<pre>";
		// var_dump($data);
		// echo "</pre>";
	}
	public function update_trainer(){
		$id=$this->input->post('id');
		$data['name']=$this->input->post('name');
		$data['designation']=$this->input->post('designation');
		$data['experience']=$this->input->post('experience');
		$data['contact']=$this->input->post('contact');
		$data['address']=$this->input->post('address');
		$data['type']=$this->input->post('type');
		$data['skills']=$this->input->post('skills');
		$data['description']=$this->input->post('description');

		$count=$this->input->post('count');
		$icon=$this->input->post('icon');
		$link=$this->input->post('link');


		$config['upload_path'] = './trainers/';
		$config['allowed_types'] = 'gif|jpg|png';
		$config['encrypt_name'] = TRUE;
		$config['max_size'] = 100000;
		$config['max_width'] = 102400;
		$config['max_height'] = 76800;
		$this->load->library('upload', $config);

		if (!$this->upload->do_upload('userfile')) {
			$error = array('error' => $this->upload->display_errors());
		} else {
			$data2 = array('upload_data' => $this->upload->data());
			$d = $data2['upload_data']['file_name'];
			$data['photo'] = $d;
		}
		$where = array('id' =>$id);
		$this->Admin_model->UpdateData('trainer',$data,$where);

		$wheres = array('trainerID' =>$id);
		$this->Admin_model->DeleteData('social_link',$wheres);
		$dd=array();
		for($i=0;$i<$count;$i++){
			$dd['icon']=$icon[$i];
			$dd['link']=$link[$i];
			$dd['trainerID']=$id;
			$this->Admin_model->SaveData('social_link',$dd);
		}
		$this->session->unset_userdata('update');
		redirect(base_url().'Admin/trainers/trainer');
	}
	public function gallery($menu){
		$session=$this->session->userdata('userID');
		if(!isset($session)){
			redirect(base_url() . 'Admin');
		}
		$session = array('menu' =>$menu);
		$this->session->set_userdata($session);
		$wh_ph=array('category'=>'Photos');
		$wh_cm=array('category'=>'Campus');
		$wh_st=array('category'=>'Students');
		$data['photo']=$this->Admin_model->SelectData('gallery','*',$wh_ph);
		$data['campus']=$this->Admin_model->SelectData('gallery','*',$wh_cm);
		$data['student']=$this->Admin_model->SelectData('gallery','*',$wh_st);
		$data['std_work']=$this->Admin_model->SelectData('std_work','*','');
		$this->load->view('gallery',$data);
	}
	private function set_upload_options()
	{   
		$config = array();
		$config['upload_path'] = './gallery/';
		$config['allowed_types'] = 'gif|jpg|png';
		// $config['max_size']      = '0';
		$config['overwrite']     = FALSE;
		$config['encrypt_name'] = TRUE;

		return $config;
	}
	public function add_gallery(){
		
		$data = array();      
		$this->load->library('upload');

		$data['category']=$this->input->post('category');
		$files = $_FILES;
		$cpt = count($_FILES['userfile']['name']);
		for($i=0; $i<$cpt; $i++)
		{           
			$_FILES['userfile']['name']= $files['userfile']['name'][$i];
			$_FILES['userfile']['type']= $files['userfile']['type'][$i];
			$_FILES['userfile']['tmp_name']= $files['userfile']['tmp_name'][$i];
			$_FILES['userfile']['error']= $files['userfile']['error'][$i];
			$_FILES['userfile']['size']= $files['userfile']['size'][$i];    

			$this->upload->initialize($this->set_upload_options());
			$this->upload->do_upload();

			$data2 = array('upload_data' => $this->upload->data());
			$d = $data2['upload_data']['file_name'];
			$data['photo'] = $d;
			if($data['category']=='photo'){
				$this->Admin_model->SaveData('std_work',$data);
			}else{
			$this->Admin_model->SaveData('gallery',$data);
		}
		}
		redirect(base_url().'Admin/gallery/gl');
	}
	public function delete_gallery($id){
		$wh=array('id'=>$id);
		$da=$this->Admin_model->SelectData_1('gallery','*',$wh);
		$im=$da->photo;
		unlink('gallery/'.$im);
		$this->Admin_model->DeleteData('gallery',$wh);
		redirect(base_url().'Admin/gallery/gl');
	}
	public function delete_std_work($id){
		$wh=array('id'=>$id);
		$da=$this->Admin_model->SelectData_1('std_work','*',$wh);
		$im=$da->photo;
		unlink('gallery/'.$im);
		$this->Admin_model->DeleteData('std_work',$wh);
		redirect(base_url().'Admin/gallery/gl');
	}
	public function add_course($menu){
		$session=$this->session->userdata('userID');
		if(!isset($session)){
			redirect(base_url() . 'Admin');
		}
		$session = array('menu' =>$menu);
		$this->session->set_userdata($session);
		$data['category']=$this->Admin_model->SelectData('course_category','*','');
		$this->load->view('add_course',$data);
	}
	public function add_coruse_post(){
		$config['upload_path'] = './course_photo/';
		$config['allowed_types'] = 'gif|jpg|png';
		$config['encrypt_name'] = TRUE;
		$config['max_size'] = 100000;
		$config['max_width'] = 102400;
		$config['max_height'] = 76800;
		$this->load->library('upload', $config);

		if (!$this->upload->do_upload('userfile')) {
			$error = array('error' => $this->upload->display_errors());
		} else {
			$data2 = array('upload_data' => $this->upload->data());
			$d = $data2['upload_data']['file_name'];
			$data['photo'] = $d;
		}
		$data['name']=$this->input->post('name');
		$data['category']=$this->input->post('category');
		$data['duration']=$this->input->post('duration');
		$data['description']=$this->input->post('description');
		$this->Admin_model->SaveData('course',$data);
		redirect(base_url().'Admin/course/course');
	}
	public function course($menu){
		$session=$this->session->userdata('userID');
		if(!isset($session)){
			redirect(base_url() . 'Admin');
		}
		$session = array('menu' =>$menu);
		$this->session->set_userdata($session);
		$data['course']=$this->Admin_model->SelectData('course','*','');
		$this->load->view('course_list',$data);
	}
	public function delete_course($id){
		$where=array('id'=>$id);
		$this->Admin_model->DeleteData('course',$where);
		redirect(base_url().'Admin/course/course');
	}
	public function edit_course($id){
		$where=array('id'=>$id);
		$data['course']=$this->Admin_model->SelectData_1('course','*',$where);
		$data['category']=$this->Admin_model->SelectData('course_category','*','');
		$this->load->view('course_edit',$data);
	}
	public function edit_coruse_post(){
		$config['upload_path'] = './course_photo/';
		$config['allowed_types'] = 'gif|jpg|png';
		$config['encrypt_name'] = TRUE;
		$config['max_size'] = 100000;
		$config['max_width'] = 102400;
		$config['max_height'] = 76800;
		$this->load->library('upload', $config);

		if (!$this->upload->do_upload('userfile')) {
			$error = array('error' => $this->upload->display_errors());
		} else {
			$data2 = array('upload_data' => $this->upload->data());
			$d = $data2['upload_data']['file_name'];
			$data['photo'] = $d;
		}
		$where=array('id'=>$this->input->post('id'));
		$data['name']=$this->input->post('name');
		$data['category']=$this->input->post('category');
		$data['duration']=$this->input->post('duration');
		$data['description']=$this->input->post('description');
		$this->Admin_model->UpdateData('course',$data,$where);
		redirect(base_url().'Admin/course/course');
	}
	public function add_course_aprt($menu){
		$session=$this->session->userdata('userID');
		if(!isset($session)){
			redirect(base_url() . 'Admin');
		}
		$session = array('menu' =>$menu);
		$this->session->set_userdata($session);
		
		$data['course']=$this->Admin_model->SelectCourse();
		$this->load->view('add_course_part',$data);
	}
	public function add_coruse_part_post(){
		$data_1['course_id']=$this->input->post('course_id');
		$data_1['head']=$this->input->post('head');
		$this->Admin_model->SaveData('part_heads',$data_1);
		$data_2['head_id']=$this->Admin_model->get_head_id()->id;
		
		$parts=$this->input->post('parts');
		
		foreach ($parts as $key => $value) {
			$data_2['parts']=$value;
			$this->Admin_model->SaveData('course_parts',$data_2);
		}
		redirect(base_url().'Admin/course/course');
	}
	public function view_course($id){
		$short=array('id'=>$id);
		$heads=array('course_id'=>$id);
		$data['course']=$this->Admin_model->SelectData_1('course','*',$short);
		$data['heads']=$this->Admin_model->SelectData('part_heads','*',$heads);
		$this->load->view('course_details',$data);
	}
	public function delete_parts($id){
		$i=explode('_', $id);
		$where=array('id'=>$i[0]);
		$this->Admin_model->DeleteData('course_parts',$where);
		redirect(base_url().'Admin/view_course/'.$i[1]);
	}
	public function edit_parts($id){
		$i=explode('_', $id);
		$where=array('id'=>$i[0]);
		$data['part']=$this->Admin_model->SelectData_1('course_parts','*',$where);
		$data['course_id']=$i[1];
		$this->load->view('edit_parts',$data);
	}
	public function edit_coruse_part_post(){
		$id=$this->input->post('part_id');
		$course_id=$this->input->post('course_id');
		$data['parts']=$this->input->post('parts');
		$where=array('id'=>$id);
		$this->Admin_model->UpdateData('course_parts',$data,$where);
		redirect(base_url().'Admin/view_course/'.$course_id);
	}
	public function batch($menu){
		$session=$this->session->userdata('userID');
		if(!isset($session)){
			redirect(base_url() . 'Admin');
		}
		$session = array('menu' =>$menu);
		$this->session->set_userdata($session);

		$data['batch']=$this->Admin_model->SelectData('batch','*','');
		$data['course']=$this->Admin_model->SelectData('course','*','');
		$this->load->view('batch',$data);
	}
	public function add_batch(){
		$data['courseID']=$this->input->post('courseID');
		$name=$this->input->post('batch_name');
		foreach ($name as $e) {
			$data['batch_name']=$e;
			$this->Admin_model->SaveData('batch',$data);
		}
		redirect(base_url() . 'Admin/batch/course');
	}
	public function delete_batch($id){
		$where=array('id'=>$id);
		$this->Admin_model->DeleteData('batch',$where);
		redirect(base_url() . 'Admin/batch/course');
	}
	public function pending($menu){
		$session=$this->session->userdata('userID');
		if(!isset($session)){
			redirect(base_url() . 'Admin');
		}
		$session = array('menu' =>$menu);
		$this->session->set_userdata($session);
		
		$where=array('approval'=>'no');
		$data['en']=$this->Admin_model->SelectData('enrollment','*',$where);	
		$data['batch']=$this->Admin_model->SelectData('batch','*','');
		$this->load->view('pending_approval',$data);
	}
	public function approve($ids){
		$content=explode('_', $ids);
		$where=array('id'=>$content[1]);
		$data['approval']='yes';
		$data['batchID']=$content[0];
		$data['price']=$content[2];
		$this->Admin_model->UpdateData('enrollment',$data,$where);
		redirect(base_url() . 'Admin/pending/std');
	}
	public function std_list($menu){
		$session=$this->session->userdata('userID');
		if(!isset($session)){
			redirect(base_url() . 'Admin');
		}
		$session = array('menu' =>$menu);
		$this->session->set_userdata($session);
		
		$where=array('approval'=>'yes','certified'=>'no');
		$data['en']=$this->Admin_model->SelectData('enrollment','*',$where);	
		$data['batch']=$this->Admin_model->SelectData('batch','*','');
		$this->load->view('std_list',$data);
	}
	public function due_fees($menu){
		$session=$this->session->userdata('userID');
		if(!isset($session)){
			redirect(base_url() . 'Admin');
		}
		$session = array('menu' =>$menu);
		$this->session->set_userdata($session);
		
		$where=array('approval'=>'yes');
		$data['en']=$this->Admin_model->SelectData('enrollment','*',$where);	
		$data['batch']=$this->Admin_model->SelectData('batch','*','');
		$this->load->view('due_fees',$data);
	}
	public function collect_fee($id){
		$session = array('menu' =>'fee');
		$this->session->set_userdata($session);

		$where=array('id'=>$id);
		$std=$this->Admin_model->SelectData_1('enrollment','*',$where);
		$where_1=array('id'=>$std->stdID);
		$data['std']=$this->Admin_model->SelectData_1('students','*',$where_1);
		$data['en_id']=$id;
		$e3=$this->Admin_model->get_payment_info($std->id);
        $due=$std->price-$e3->amount;
        $data['due']=$due;
        $where_c=array('id'=>$std->courseID);
        $data['course']=$this->Admin_model->SelectData_1('course','*',$where_c);
        $where_b=array('id'=>$std->batchID);
        $data['batch']=$this->Admin_model->SelectData_1('batch','*','');
        $this->load->view('collect_fee_link',$data);
	}
	public function collection_post(){
		$datas=$this->input->post();
		$datas['date']=date('d/m/Y');

		$id=$this->input->post('enroll_id');
		$amount=$this->input->post('amount');
		$payment=$this->Admin_model->get_payment_info($id);
		$price=$this->Admin_model->get_price_info($id);
		$datas['due']=$price->price-$payment->amount-$amount;
		$this->Admin_model->SaveData('payment',$datas);
		
		$dd=$this->Admin_model->get_max_payment_id();
		redirect(base_url().'Admin/print_collection/'.$dd->id);
	}
	public function print_collection($id){
		$session = array('menu' =>'fee');
		$this->session->set_userdata($session);

		$pp=$this->Admin_model->get_max_payment($id);
		$data['p_id']=$id;
		$where=array('id'=>$pp->enroll_id);
		$std=$this->Admin_model->SelectData_1('enrollment','*',$where);
		$where_1=array('id'=>$std->stdID);
		$data['std']=$this->Admin_model->SelectData_1('students','*',$where_1);
		$data['en_id']=$id;
		$e3=$this->Admin_model->get_payment_info($std->id);
        $due=$std->price-$e3->amount;
        $data['due']=$pp->due;
        $where_c=array('id'=>$std->courseID);
        $data['course']=$this->Admin_model->SelectData_1('course','*',$where_c);
        $where_b=array('id'=>$std->batchID);
        $data['batch']=$this->Admin_model->SelectData_1('batch','*','');

        $data['amount']=$pp->amount;
        $data['date']=$pp->date;
        $this->load->view('collection_print',$data);
	}
	public function collect_fees(){
		$session = array('menu' =>'fee');
		$this->session->set_userdata($session);
		$this->load->view('collect_fees');
	}
	public function get_payment_info(){
		$session = array('menu' =>'fee');
		$this->session->set_userdata($session);

		$id=$this->input->post('id');
		$where=array('id'=>$id);
		$std=$this->Admin_model->SelectData_1('enrollment','*',$where);
		$where_1=array('id'=>$std->stdID);
		$st=$this->Admin_model->SelectData_1('students','*',$where_1);
		$data['std_name']=$st->name;
		$data['email']=$st->email;
		$data['mobile']=$st->mobile;
		$data['en_id']=$id;
		$e3=$this->Admin_model->get_payment_info($std->id);
        $due=$std->price-$e3->amount;
        $data['due']=$due;
        $where_c=array('id'=>$std->courseID);
        $c=$this->Admin_model->SelectData_1('course','*',$where_c);
        $data['course_name']=$c->name;
        $where_b=array('id'=>$std->batchID);
        $b=$this->Admin_model->SelectData_1('batch','*','');
        $data['batch']=$b->batch_name;
        echo json_encode($data);
	}
	public function paid_fees($menu){
		$session = array('menu' =>'fee');
		$this->session->set_userdata($session);

		$session=$this->session->userdata('userID');
		if(!isset($session)){
			redirect(base_url() . 'Admin');
		}
		$session = array('menu' =>$menu);
		$this->session->set_userdata($session);
		
		$data['pay']=$this->Admin_model->SelectData('payment','*','');	
		// $data['batch']=$this->Admin_model->SelectData('batch','*','');
		$this->load->view('paid_fees',$data);
	}
	public function add_notice($menu){
		$session = array('menu' =>$menu);
		$this->session->set_userdata($session);
		$this->load->view('add_notice');
	}
	public function notice_post(){
		$data=$this->input->post();
		$data['date']=date('d-m-Y');

		$config['upload_path'] = './notice_files/';
		$config['allowed_types'] = 'gif|jpg|png|pdf|doc|docx';
		$config['encrypt_name'] = TRUE;
		$config['max_size'] = 100000;
		$config['max_width'] = 102400;
		$config['max_height'] = 76800;
		$this->load->library('upload', $config);

		if (!$this->upload->do_upload('photo')) {
			$error = array('error' => $this->upload->display_errors());
		} else {
			$data2 = array('upload_data' => $this->upload->data());
			$d = $data2['upload_data']['file_name'];
			$data['photo'] = $d;
		}
		if (!$this->upload->do_upload('files')) {
			$error = array('error' => $this->upload->display_errors());
		} else {
			$data21 = array('upload_data' => $this->upload->data());
			$d1 = $data21['upload_data']['file_name'];
			$data['file'] = $d1;
		}
		$this->Admin_model->SaveData('notice',$data);
		redirect(base_url().'Admin/notice_list/n');
	}
	public function notice_list($menu){
		$session = array('menu' =>$menu);
		$this->session->set_userdata($session);
		$data['notice']=$this->Admin_model->SelectDataOrder('notice','*','','id','desc');
		$this->load->view('notice_list',$data);
	}
	public function view_notice($id){
		$where=array('id'=>$id);
		$data['notice']=$this->Admin_model->SelectData_1('notice','*',$where);
		$this->load->view('notice_details',$data);
	}
	public function edit_notice($id){
		$where=array('id'=>$id);
		$data['notice']=$this->Admin_model->SelectData_1('notice','*',$where);
		$this->load->view('edit_notice',$data);
	}
	public function notice_edit(){
		$data=$this->input->post();
		
		$id=$this->input->post('id');
		$where=array('id'=>$id);

		$config['upload_path'] = './notice_files/';
		$config['allowed_types'] = 'gif|jpg|png|pdf|doc|docx';
		$config['encrypt_name'] = TRUE;
		$config['max_size'] = 100000;
		$config['max_width'] = 102400;
		$config['max_height'] = 76800;
		$this->load->library('upload', $config);

		if (!$this->upload->do_upload('photo')) {
			$error = array('error' => $this->upload->display_errors());
		} else {
			$data2 = array('upload_data' => $this->upload->data());
			$d = $data2['upload_data']['file_name'];
			$data['photo'] = $d;
		}
		if (!$this->upload->do_upload('files')) {
			$error = array('error' => $this->upload->display_errors());
		} else {
			$data21 = array('upload_data' => $this->upload->data());
			$d1 = $data21['upload_data']['file_name'];
			$data['file'] = $d1;
		}
		$this->Admin_model->UpdateData('notice',$data,$where);
		redirect(base_url().'Admin/notice_list/n');
	}
	public function delete_notice($id){
		$where=array('id'=>$id);
		$this->Admin_model->DeleteData('notice',$where);
		redirect(base_url().'Admin/notice_list/n');
	}
	public function mark_as_certified($id){
		$where=array('id'=>$id);
		$data['certified']='yes';
		$this->Admin_model->UpdateData('enrollment',$data,$where);
		redirect(base_url().'Admin/std_list/std');
	}
	public function service_type($menu){
		$session = array('menu' =>$menu);
		$this->session->set_userdata($session);
		$data['service']=$this->Admin_model->SelectDataOrder('services','*','','id','desc');
		$this->load->view('service_type',$data);
	}
	public function add_service_post(){
		$data=$this->input->post();
		$this->Admin_model->SaveData('services',$data);
		redirect(base_url().'Admin/service_type/service');
	}
	public function delete_service_type($id){
		$where=array('id'=>$id);
		$this->Admin_model->DeleteData('services',$where);
		redirect(base_url().'Admin/service_type/service');
	}
	public function service_news($menu){
		$session = array('menu' =>$menu);
		$this->session->set_userdata($session);
		$data['service']=$this->Admin_model->SelectDataOrder('service_news','*','','id','desc');
		$data['type']=$this->Admin_model->SelectDataOrder('services','*','','id','desc');
		$this->load->view('service_news',$data);
	}
	public function add_service_news_post(){
		$data=$this->input->post();

		$config['upload_path'] = './service_files/';
		$config['allowed_types'] = 'gif|jpg|png';
		$config['encrypt_name'] = TRUE;
		$config['max_size'] = 100000;
		$config['max_width'] = 102400;
		$config['max_height'] = 76800;
		$this->load->library('upload', $config);

		if (!$this->upload->do_upload('photo')) {
			$error = array('error' => $this->upload->display_errors());
		} else {
			$data2 = array('upload_data' => $this->upload->data());
			$d = $data2['upload_data']['file_name'];
			$data['photo'] = $d;
		}
		$this->Admin_model->SaveData('service_news',$data);
		redirect(base_url().'Admin/service_news/service');
	}
	public function edit_service_news($id){
		$where=array('id'=>$id);
		$data['news']=$this->Admin_model->SelectData_1('service_news','*',$where);
		$data['type']=$this->Admin_model->SelectDataOrder('services','*','','id','desc');
		$this->load->view('update_service_news',$data);
	}
	public function edit_service_news_post(){
		$data['head']=$this->input->post('head');
		$data['news']=$this->input->post('news');
		$id=$this->input->post('id');
		$where=array('id'=>$id);

		$config['upload_path'] = './service_files/';
		$config['allowed_types'] = 'gif|jpg|png';
		$config['encrypt_name'] = TRUE;
		$config['max_size'] = 100000;
		$config['max_width'] = 102400;
		$config['max_height'] = 76800;
		$this->load->library('upload', $config);

		if (!$this->upload->do_upload('photo')) {
			$error = array('error' => $this->upload->display_errors());
		} else {
			$data2 = array('upload_data' => $this->upload->data());
			$d = $data2['upload_data']['file_name'];
			$data['photo'] = $d;
		}
		$this->Admin_model->UpdateData('service_news',$data,$where);
		redirect(base_url().'Admin/service_news/service');
	}
	public function delete_service_news($id){
		$where=array('id'=>$id);
		$this->Admin_model->DeleteData('service_news',$where);
		redirect(base_url().'Admin/service_news/service');
	}
	public function view_service_news($id){
		$where=array('id'=>$id);
		$data['news']=$this->Admin_model->SelectData_1('service_news','*',$where);
		$data['type']=$this->Admin_model->SelectDataOrder('services','*','','id','desc');
		$this->load->view('view_service_news',$data);
	}
}
?>