<?php

$this->load->view('header');
?>

<div class="main-content">
  <section class="inner-header divider parallax layer-overlay overlay-dark-5" data-bg-img="<?=base_url()?>images/bg/bg3.jpg">
    <div class="container pt-70 pb-20">
      <div class="section-content">
        <div class="row">
          <div class="col-md-12">
            <h2 class="title text-white">Registration</h2>
            <ol class="breadcrumb text-left text-black mt-10">
              <li><a href="page-teachers-details.html#">Home</a></li>
              <li><a href="page-teachers-details.html#">Pages</a></li>
              <li class="active text-gray-silver">Page Title</li>
            </ol>
          </div>
        </div>
      </div>
    </div>
  </section>

  <!-- Start main-content -->
  <div class="main-content">
  <form action="<?=base_url().'front/Front/registration'?>" method="post" enctype="multipart/form-data" id="f">
     <div class="col-md-12">
      <div class="col-md-10 col-md-offset-1">
        <h4 class="heading-title">Don't have an Account? Register Now</h4>
        <div class="form-group col-md-6">
          <label>Course</label>
          <select class="form-control" name="courseID" id="courseID" >
            <option>Select Course</option>
            <?php
              foreach ($course as $e) {
            ?>
            <option value="<?=$e->id?>"><?=$e->name?></option>
            <?php } ?>
          </select> 
        </div>
        <div class="form-group col-md-6">
          <label>Shift</label>
          <span id="batch">
          <select class="form-control" name="batch">
            <option value="">Select Shift</option>
            <option value="10:00am--1:00pm">10:00am--1:00pm</option>
            <option value="1:00pm--4:00pm">1:00pm--4:00pm</option>
            <option value="4:00pm--7:00pm">4:00pm--7:00pm</option>
          </select> 
          </span>
        </div>
        <div class="form-group col-md-6">
          <label>Name</label>
          <input type="text" class="form-control" name="name">
        </div>
        <div class="form-group col-md-6">
          <label>Father's Name</label>
          <input type="text" class="form-control" name="father">
        </div>
        <div class="form-group col-md-6">
          <label>Mother's Name</label>
          <input type="text" class="form-control" name="mother">
        </div>
        <div class="form-group col-md-6">
          <label>Email Address</label>
          <input type="email" class="form-control" name="email">
        </div>
      </div>
     <!--  <div class="col-md-6">
        <h4 class="heading-title">Permanent's Address</h4>
        <div class="form-group col-md-6">
          <label>Village/Street</label>
          <input type="text" class="form-control" name="p_village">
        </div>
        <div class="form-group col-md-6">
          <label>Post</label>
          <input type="text" class="form-control" name="p_post">
        </div>
        <div class="form-group col-md-6">
          <label>Upzilla</label>
          <input type="text" class="form-control" name="p_upozila">
        </div>
        <div class="form-group col-md-6">
          <label>District</label>
          <input type="text" class="form-control" name="p_district">
        </div>
        <div class="form-group col-md-6">
          <label>Zip Code</label>
          <input type="text" class="form-control" name="p_zip">
        </div>
      </div> -->
      <div class="col-md-10 col-md-offset-1">
        <div class="form-group col-md-6">
          <label>Date of Birth</label>
          <input type="date" class="form-control" name="date_of_birth">
        </div>
        <div class="form-group col-md-6">
          <label>Nationality</label>
          <input type="text" class="form-control" name="nationality">
        </div>
        <div class="form-group col-md-6">
          <label>Religion</label>
          <input type="text" class="form-control" name="religion">
        </div>
        <div class="form-group col-md-6">
          <label>Blood Group</label>
          <select class="form-control" name="blood">
            <option>Select Blood Group</option>
            <option value="A+">A+</option>
            <option value="A-">A-</option>
            <option value="B+">B+</option>
            <option value="B-">B-</option>
            <option value="O+">O+</option>
            <option value="O-">O-</option>
            <option value="AB+">AB+</option>
            <option value="AB-">AB-</option>
          </select> 
        </div>
      </div>
      <div class="clearfix">
      </div>
      <!-- <div class="col-md-6" >
        <div class="col-md-12">
          <h4 class="heading-title">Gurdian's Contact </h4>
          <div class="form-group">
            <label>Gurdian's Name</label>
            <input type="text" class="form-control" name="guardian">
          </div>
          <div class="form-group">
            <label>Mobile</label>
            <input type="text" class="form-control" name="g_mobile">
          </div>
        </div>
      </div> -->
      <div class="col-md-10 col-md-offset-1">
      <div class="form-group col-md-6">
          <label>Mobile</label>
          <input type="text" class="form-control" name="mobile">
        </div>
        <div class="heading-line-bottom col-md-12">
        <h4 class="heading-title">Present's Address</h4>
        </div>
        <div class="form-group col-md-6">
          <label>Village/Street</label>
          <input type="text" class="form-control" name="pr_village">
        </div>
        <div class="form-group col-md-6">
          <label>Post</label>
          <input type="text" class="form-control" name="pr_post">
        </div>
        <div class="form-group col-md-6">
          <label>Upzilla</label>
          <input type="text" class="form-control" name="pr_upozila">
        </div>
        <div class="form-group col-md-6">
          <label>District</label>
          <input type="text" class="form-control" name="pr_district">
        </div>
        <div class="form-group col-md-6">
          <label>Zip Code</label>
          <input type="text" class="form-control" name="pr_zip">
        </div>
      </div>

      <div class="col-md-10 col-md-offset-1">
        <h4 class="heading-title">Educational Background</h4>
        <div class="form-group col-md-6">
          <label>Highest Degree</label>
          <input type="text" class="form-control" name="degree">
        </div>
        <div class="form-group col-md-6">
          <label>Institution</label>
          <input type="text" class="form-control" name="institution">
        </div>
        <div class="form-group col-md-6">
          <label>Passing Year</label>
          <input type="text" class="form-control" name="pass_year">
        </div>
        <div class="form-group col-md-6">
          <label>Result</label>
          <input type="text" class="form-control" name="result">
        </div>
      </div>
      <div class="col-md-10 col-md-offset-1">
        <div class="col-md-12">
          <h4 class="heading-title">Upload Your recent Photo</h4>
          <div class="form-group">
            <label for="exampleInputFile">Upload Picture</label>
            <input type="file" id="exampleInputFile" name="userfile">
            <p class="help-block">Picture size 300x300 .</p>
          </div>
          <div class="checkbox">
            <label id="t">
              <input type="checkbox" name="term" id="term" value="ok">
              I read all terms and condition </label>
            </div>
            <div class="form-group">
              <a class="btn btn-default" onclick="submit()">Register Now</a>
            </div>
          </div>
        </div>
      </div>
      <!-- end main-content -->
      </form>
    </div>
    <?php
    $this->load->view('footer');
    ?>
    <script type="text/javascript">
      function submit(){
        var term=$('#term:checked').val();
        if(term=='ok'){
          $('#f').submit();
        }else{
          $('#t').css('color','red')
        }
      }
      function get_batch(){
        var courseID=$('#courseID').val();
        var base = '<?php echo base_url() ?>';
                    $.ajax({
                        url: base + 'Front/get_batch',
                        method: 'post',
                        data: {
                            id: courseID
                        },
                        success: function (data) {
                            $('#batch').html(data);
                        }
                    })
      }
    </script>